from hello.name import print_hi


def hi():
    print_hi()
