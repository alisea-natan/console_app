
### _USING poetry_
1) `brew install poetry` // for macOS (you can find installation instructions here https://python-poetry.org/docs/)
1) `poetry config virtualenvs.in-project true` // .venv will be in the project dir
1) `poetry install` // install all dependencies
1) `poetry shell` // activate venv
1) `poetry run say-hello` // run script
1) `poetry run say-hello -n Name` // run script with options using click module
   
### _USING setuptools_
1) `python3 setup.py install`
1) `greeting`
1) `greeting -n Name`
